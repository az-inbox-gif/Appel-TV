import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Play, Info, Star } from 'lucide-react';
import { getImageUrl } from '../lib/tmdb';

export default function HeroCarousel({ items, type = 'movie' }: { items: any[], type?: string }) {
  if (!items || items.length === 0) return <div className="h-[60vh] md:h-[80vh] w-full bg-white/5 animate-pulse rounded-3xl" />;

  const item = items[0]; // Just showing the top one for simplicity in this demo
  
  const title = type === 'anime' ? (item?.title?.english || item?.title?.romaji || 'Unknown') : (item?.title || item?.name || 'Unknown');
  const overview = item?.overview || item?.description?.replace(/<[^>]*>?/gm, '');
  const backdrop = type === 'anime' 
    ? item?.bannerImage || item?.coverImage?.extraLarge 
    : getImageUrl(item?.backdrop_path, 'original');
  const rating = type === 'anime' ? (item?.averageScore ? (item.averageScore / 10).toFixed(1) : null) : item?.vote_average?.toFixed(1);
  const id = item?.id;

  return (
    <div className="relative h-[60vh] md:h-[80vh] w-full max-w-[1600px] mx-auto px-4 md:px-8 mb-12">
      <div className="absolute inset-4 md:inset-8 rounded-[2rem] overflow-hidden">
        <img 
          src={backdrop} 
          alt={title} 
          className="w-full h-full object-cover object-center scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-[#0a0a0c]/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0c] via-[#0a0a0c]/50 to-transparent" />
      </div>

      <div className="absolute bottom-12 md:bottom-24 left-8 md:left-20 max-w-2xl z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center gap-3 mb-4"
        >
          <span className="px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold uppercase tracking-wider">
            {type === 'tv' ? 'Series' : type}
          </span>
          {rating && (
            <span className="flex items-center gap-1 text-yellow-400 text-sm font-semibold">
              <Star className="w-4 h-4 fill-current" /> {rating}
            </span>
          )}
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-6xl font-bold mb-4 tracking-tight drop-shadow-lg"
        >
          {title}
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-white/70 text-sm md:text-lg mb-8 line-clamp-3 max-w-xl drop-shadow-md"
        >
          {overview}
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex items-center gap-4"
        >
          <Link 
            to={`/watch/${type}/${id}`}
            className="flex items-center gap-2 px-8 py-4 rounded-2xl bg-white text-black font-semibold hover:scale-105 transition-transform shadow-[0_0_40px_rgba(255,255,255,0.3)]"
          >
            <Play className="w-5 h-5 fill-current" /> Play Now
          </Link>
          <button className="flex items-center gap-2 px-8 py-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white font-semibold hover:bg-white/20 transition-colors">
            <Info className="w-5 h-5" /> More Info
          </button>
        </motion.div>
      </div>
    </div>
  );
}
