const TMDB_API_KEY = 'd7b840a9ab64365b87b2a1376ddd958d';
const BASE_URL = 'https://api.themoviedb.org/3';

export const fetchTMDB = async (endpoint: string, params: Record<string, string> = {}) => {
  const query = new URLSearchParams({ api_key: TMDB_API_KEY, ...params }).toString();
  const res = await fetch(`${BASE_URL}${endpoint}?${query}`);
  if (!res.ok) throw new Error(`TMDB error: ${res.status}`);
  return res.json();
};

export const getImageUrl = (path: string, size = 'w500') => {
  if (!path) return 'https://via.placeholder.com/500x750?text=No+Image';
  return `https://image.tmdb.org/t/p/${size}${path}`;
};
