import { useEffect, useState } from 'react';
import HeroCarousel from '../components/HeroCarousel';
import MediaRow from '../components/MediaRow';
import { fetchTMDB } from '../lib/tmdb';

export default function Movies() {
  const [popular, setPopular] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [upcoming, setUpcoming] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [popRes, topRes, upRes] = await Promise.all([
          fetchTMDB('/movie/popular'),
          fetchTMDB('/movie/top_rated'),
          fetchTMDB('/movie/upcoming')
        ]);

        setPopular(popRes.results);
        setTopRated(topRes.results);
        setUpcoming(upRes.results);
      } catch (error) {
        console.error('Failed to fetch movies:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="pb-10">
      <HeroCarousel items={popular} type="movie" />
      <MediaRow title="Popular Movies" items={popular} type="movie" />
      <MediaRow title="Top Rated Movies" items={topRated} type="movie" />
      <MediaRow title="Upcoming Movies" items={upcoming} type="movie" />
    </div>
  );
}
