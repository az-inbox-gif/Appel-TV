import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchTMDB, getImageUrl } from '../lib/tmdb';
import { fetchAniList, ANILIST_QUERIES } from '../lib/anilist';
import { Settings, BookmarkPlus, BookmarkCheck, ListPlus } from 'lucide-react';
import supabase from '../lib/supabase';
import CustomSelect from '../components/CustomSelect';

const PROVIDERS = {
  movie: [
    { id: 'vidsrc', name: 'VidSrc', url: (id: string) => `https://vidsrc.net/embed/movie?tmdb=${id}` },
    { id: 'vidsrc-cc', name: 'VidSrc.cc', url: (id: string) => `https://vidsrc.cc/v2/embed/movie/${id}` },
    { id: 'autoembed', name: 'AutoEmbed', url: (id: string) => `https://player.autoembed.cc/embed/movie/${id}` },
    { id: 'embedsu', name: 'Embed.su', url: (id: string) => `https://embed.su/embed/movie/${id}` },
    { id: 'vidlink', name: 'VidLink', url: (id: string) => `https://vidlink.pro/movie/${id}` },
    { id: '111movies', name: '111Movies', url: (id: string) => `https://111movies.net/movie/${id}` },
    { id: 'filmu', name: 'FilmU', url: (id: string) => `https://embed.filmu.in/movie/${id}` },
  ],
  tv: [
    { id: 'vidsrc', name: 'VidSrc', url: (id: string, s: number, e: number) => `https://vidsrc.net/embed/tv?tmdb=${id}&season=${s}&episode=${e}` },
    { id: 'vidsrc-cc', name: 'VidSrc.cc', url: (id: string, s: number, e: number) => `https://vidsrc.cc/v2/embed/tv/${id}/${s}/${e}` },
    { id: 'autoembed', name: 'AutoEmbed', url: (id: string, s: number, e: number) => `https://player.autoembed.cc/embed/tv/${id}/${s}/${e}` },
    { id: 'embedsu', name: 'Embed.su', url: (id: string, s: number, e: number) => `https://embed.su/embed/tv/${id}/${s}/${e}` },
    { id: 'vidlink', name: 'VidLink', url: (id: string, s: number, e: number) => `https://vidlink.pro/tv/${id}/${s}/${e}` },
    { id: 'filmu', name: 'FilmU', url: (id: string, s: number, e: number) => `https://embed.filmu.in/tv/${id}/${s}/${e}` },
  ],
  anime: [
    { id: 'vidnest', name: 'VidNest Pahe', url: (id: string, ep: number, type: string) => `https://vidnest.fun/animepahe/${id}/${ep}/${type}` },
    { id: 'yummyani', name: 'YummyAnime', url: (id: string, ep: number) => `https://api.yani.tv/anime/${id}/videos` },
    { id: 'vidsrc', name: 'VidSrc', url: (id: string, ep: number) => `https://vidsrc.net/embed/tv?tmdb=${id}&season=1&episode=${ep}` },
    { id: 'vidsrc-cc', name: 'VidSrc.cc', url: (id: string, ep: number) => `https://vidsrc.cc/v2/embed/tv/${id}/1/${ep}` },
    { id: 'autoembed', name: 'AutoEmbed', url: (id: string, ep: number) => `https://player.autoembed.cc/embed/tv/${id}/1/${ep}` },
    { id: 'embedsu', name: 'Embed.su', url: (id: string, ep: number) => `https://embed.su/embed/tv/${id}/1/${ep}` },
    { id: 'vidlink', name: 'VidLink', url: (id: string, ep: number) => `https://vidlink.pro/tv/${id}/1/${ep}` },
    { id: 'filmu', name: 'FilmU', url: (id: string, ep: number) => `https://embed.filmu.in/tv/${id}/1/${ep}` }
  ]
};

export default function Watch({ session }: { session: any }) {
  const { type, id } = useParams<{ type: string, id: string }>();
  const [details, setDetails] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // Player state
  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(1);
  const [subDub, setSubDub] = useState('sub');
  const [provider, setProvider] = useState<any>(null);
  
  const [bookmarkStatus, setBookmarkStatus] = useState<string | null>(null);

  const [yummyUrl, setYummyUrl] = useState('');
  const [tmdbId, setTmdbId] = useState<string | null>(null);
  const [relatedAnime, setRelatedAnime] = useState<any[]>([]);
  const [iframeLoading, setIframeLoading] = useState(true);

  // Default provider logic separated from data fetching
  useEffect(() => {
    const fetchProfile = async () => {
      if (session?.user) {
        try {
          const { data } = await supabase.auth.getSession();
          const profRes = await fetch('/api/profile', { headers: { Authorization: `Bearer ${data.session?.access_token}` } });
          if (profRes.ok) {
            const profile = await profRes.json();
            if (type === 'anime' && profile.default_anime_provider) {
              const p = PROVIDERS.anime.find(x => x.id === profile.default_anime_provider || x.name === profile.default_anime_provider);
              if (p) setProvider(p);
            } else if (type !== 'anime' && profile.default_movie_provider) {
              const p = PROVIDERS[type as 'movie' | 'tv'].find(x => x.id === profile.default_movie_provider || x.name === profile.default_movie_provider);
              if (p) setProvider(p);
            }
          }
        } catch(e) {}
      }
    };
    fetchProfile();
  }, [session, type]);

  useEffect(() => {
    if (!type || !id) return;

    const loadDetails = async () => {
      try {
        setLoading(true);

        if (type === 'anime') {
          const res = await fetchAniList(ANILIST_QUERIES.details, { id: parseInt(id) });
          setDetails(res.Media);
          
          // Only set default if we don't have one from profile yet
          setProvider((prev: any) => prev || PROVIDERS.anime[0]);
          
          // Try to find TMDB ID for other providers
          try {
            const title = res.Media.title.english || res.Media.title.romaji;
            const searchRes = await fetchTMDB('/search/tv', { query: title });
            if (searchRes.results && searchRes.results.length > 0) {
              setTmdbId(searchRes.results[0].id.toString());
            }

            // Fetch related seasons/sequels from AniList
            const relationsRes = await fetchAniList(ANILIST_QUERIES.relations, { id: parseInt(id) });
            if (relationsRes?.Media?.relations?.edges) {
              const sequels = relationsRes.Media.relations.edges
                .filter((edge: any) => 
                  (edge.relationType === 'SEQUEL' || edge.relationType === 'PREQUEL' || edge.relationType === 'ALTERNATIVE') && 
                  edge.node.type === 'ANIME' &&
                  (edge.node.format === 'TV' || edge.node.format === 'ONA')
                )
                .map((edge: any) => edge.node);
              setRelatedAnime(sequels);
            }
            
            // Try to find YummyAnime ID
            const yummyRes = await fetch(`https://api.yani.tv/anime?q=${encodeURIComponent(title)}&limit=1`);
            if (yummyRes.ok) {
              const yummyData = await yummyRes.json();
              if (yummyData.response && yummyData.response.length > 0) {
                const yummyId = yummyData.response[0].anime_id;
                const videosRes = await fetch(`https://api.yani.tv/anime/${yummyId}/videos`);
                if (videosRes.ok) {
                  const videosData = await videosRes.json();
                  const targetVideo = videosData.response.find((v: any) => v.index === episode || v.number === episode.toString());
                  if (targetVideo) {
                    setYummyUrl(targetVideo.iframe_url);
                  } else if (videosData.response.length > 0) {
                    setYummyUrl(videosData.response[0].iframe_url); // Fallback to first video
                  }
                }
              }
            }
          } catch (e) {
            console.error('Failed to find external IDs for anime', e);
          }
        } else {
          const res = await fetchTMDB(`/${type}/${id}`);
          setDetails(res);
          setProvider((prev: any) => prev || PROVIDERS[type as 'movie' | 'tv'][0]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadDetails();
  }, [type, id]);

  // Update Yummy URL when episode changes
  useEffect(() => {
    if (type !== 'anime' || provider?.id !== 'yummyani' || !details) return;
    
    const fetchYummyEpisode = async () => {
      try {
        const title = details.title.english || details.title.romaji;
        const yummyRes = await fetch(`https://api.yani.tv/anime?q=${encodeURIComponent(title)}&limit=1`);
        if (yummyRes.ok) {
          const yummyData = await yummyRes.json();
          if (yummyData.response && yummyData.response.length > 0) {
            const yummyId = yummyData.response[0].anime_id;
            const videosRes = await fetch(`https://api.yani.tv/anime/${yummyId}/videos`);
            if (videosRes.ok) {
              const videosData = await videosRes.json();
              const targetVideo = videosData.response.find((v: any) => v.index === episode || v.number === episode.toString());
              if (targetVideo) {
                setYummyUrl(targetVideo.iframe_url);
              }
            }
          }
        }
      } catch (e) {
        console.error('Failed to fetch yummy episode', e);
      }
    };
    
    fetchYummyEpisode();
  }, [episode, provider, details, type]);

  useEffect(() => {
    if (session?.user && details) {
      checkBookmark();
      saveHistory();
    }
  }, [session, details, episode, season]);

  const checkBookmark = async () => {
    if (!session?.user) return;
    try {
      const { data } = await supabase.auth.getSession();
      const res = await fetch('/api/watchlist', {
        headers: { Authorization: `Bearer ${data.session?.access_token}` }
      });
      const watchlist = await res.json();
      const item = watchlist.find((b: any) => b.media_id === id && b.media_type === type);
      if (item) setBookmarkStatus(item.status);
      else setBookmarkStatus(null);
    } catch (e) { console.error(e); }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!session?.user) return alert('Please login to use the watchlist');
    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      
      if (newStatus === 'Remove') {
        await fetch('/api/watchlist', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ media_id: id, media_type: type })
        });
        setBookmarkStatus(null);
      } else {
        const title = type === 'anime' ? (details.title.english || details.title.romaji) : (details.title || details.name);
        const poster = type === 'anime' ? details.coverImage.large : details.poster_path;
        await fetch('/api/watchlist', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ media_id: id, media_type: type, title, poster_path: poster, status: newStatus })
        });
        setBookmarkStatus(newStatus);
      }
    } catch (e) { console.error(e); }
  };

  const saveHistory = async () => {
    if (!session?.user || !details) return;
    try {
      const { data } = await supabase.auth.getSession();
      const title = type === 'anime' ? (details.title.english || details.title.romaji) : (details.title || details.name);
      const poster = type === 'anime' ? details.coverImage.large : details.poster_path;
      
      await fetch('/api/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${data.session?.access_token}` },
        body: JSON.stringify({ 
          media_id: id, media_type: type, title, poster_path: poster, 
          episode: type !== 'movie' ? episode : null, 
          season: type === 'tv' ? season : null,
          progress: 0
        })
      });
    } catch (e) { console.error(e); }
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;
  if (!details) return <div className="p-8 text-center">Not found</div>;

  const title = type === 'anime' ? (details.title.english || details.title.romaji) : (details.title || details.name);
  const overview = type === 'anime' ? details.description?.replace(/<[^>]*>?/gm, '') : details.overview;
  
  let iframeUrl = '';
  if (provider) {
    if (type === 'movie') iframeUrl = provider.url(id);
    else if (type === 'tv') iframeUrl = provider.url(id, season, episode);
    else if (type === 'anime') {
      if (provider.id === 'vidnest') {
        iframeUrl = provider.url(id, episode, subDub);
      } else if (provider.id === 'yummyani') {
        iframeUrl = yummyUrl;
      } else if (tmdbId) {
        iframeUrl = provider.url(tmdbId, episode);
      }
    }
  }

  useEffect(() => {
    if (iframeUrl) setIframeLoading(true);
  }, [iframeUrl]);

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 pb-12">
      <div className="flex flex-col xl:flex-row gap-6 mb-8">
        {/* Player Section */}
        <div className="relative w-full xl:w-3/4 aspect-video bg-black rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl group">
          {iframeUrl ? (
            <>
              {iframeLoading && (
                <div className="absolute inset-0 z-20 bg-white flex items-center justify-center">
                  <video 
                    src="https://v1.pinimg.com/videos/mc/720p/13/02/6b/13026b551f9f5d357c7c95b78f9e57af.mp4" 
                    autoPlay loop muted playsInline 
                    className="w-64 h-64 object-contain"
                  />
                </div>
              )}
              <iframe 
                src={iframeUrl} 
                className={`w-full h-full border-0 transition-opacity duration-500 ${iframeLoading ? 'opacity-0' : 'opacity-100'}`} 
                allowFullScreen 
                title="Player"
                onLoad={() => setIframeLoading(false)}
              />
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-white/50 text-center px-4">
              {type === 'anime' && provider?.id === 'yummyani' && !yummyUrl
                ? "Could not find this anime on YummyAnime. Try VidNest Pahe."
                : type === 'anime' && provider?.id !== 'vidnest' && provider?.id !== 'yummyani' && !tmdbId 
                ? "Could not find a TMDB mapping for this anime to use with this provider. Try VidNest Pahe."
                : "Select a provider"}
            </div>
          )}
        </div>

        {/* Episodes / Seasons Sidebar (for TV and Anime) */}
        {(type === 'tv' || type === 'anime') && (
          <div className="w-full xl:w-1/4 bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] p-4 flex flex-col h-[300px] xl:h-auto xl:aspect-[1/1.5] xl:max-h-[calc(75vw*9/16)]">
            <h3 className="font-semibold text-lg mb-4 px-2">Episodes</h3>
            
            {(type === 'tv' || type === 'anime') && (
              <div className="mb-4">
                {type === 'tv' ? (
                  <CustomSelect
                    value={season.toString()}
                    onChange={(val: string) => { setSeason(Number(val)); setEpisode(1); }}
                    options={Array.from({ length: details.number_of_seasons || 10 }).map((_, i) => ({
                      value: (i + 1).toString(),
                      label: `Season ${i + 1}`
                    }))}
                  />
                ) : (
                  <CustomSelect
                    value={id || ''}
                    onChange={(val: string) => { window.location.href = `/watch/anime/${val}`; }}
                    options={[
                      { value: id || '', label: 'Current Season' },
                      ...relatedAnime.map((anime) => ({
                        value: anime.id.toString(),
                        label: anime.title.english || anime.title.romaji
                      }))
                    ]}
                  />
                )}
              </div>
            )}

            <div className="flex-1 overflow-y-auto scrollbar-hide space-y-2 pr-2">
              {Array.from({ length: type === 'anime' ? (details.episodes || 100) : (details.seasons?.find((s:any) => s.season_number === season)?.episode_count || 50) }).map((_, i) => {
                const epNum = i + 1;
                const isActive = episode === epNum;
                return (
                  <button
                    key={epNum}
                    onClick={() => setEpisode(epNum)}
                    className={`w-full text-left px-4 py-3 rounded-xl transition-all ${
                      isActive 
                        ? 'bg-white text-black font-bold shadow-lg' 
                        : 'bg-black/20 hover:bg-white/10 text-white/70 hover:text-white'
                    }`}
                  >
                    Episode {epNum}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Info Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">{title}</h1>
              <div className="flex items-center gap-4 text-white/60 text-sm">
                {type === 'tv' && <span>Season {season} Episode {episode}</span>}
                {type === 'anime' && <span>Episode {episode} • {subDub.toUpperCase()}</span>}
                {details.vote_average && <span>★ {details.vote_average.toFixed(1)}</span>}
                {details.averageScore && <span>★ {(details.averageScore / 10).toFixed(1)}</span>}
              </div>
            </div>
            <div className="w-48">
              <CustomSelect
                value={bookmarkStatus || ''}
                onChange={(val: string) => handleStatusChange(val)}
                placeholder="Add to List"
                icon={bookmarkStatus ? <BookmarkCheck className="w-4 h-4 text-indigo-400" /> : <ListPlus className="w-4 h-4 text-white/50" />}
                options={[
                  { value: 'Watching', label: 'Watching' },
                  { value: 'Planning To Watch', label: 'Plan to Watch' },
                  { value: 'Watched', label: 'Completed' },
                  { value: 'Dropped', label: 'Dropped' },
                  ...(bookmarkStatus ? [{ value: 'Remove', label: <span className="text-red-400">Remove from List</span> }] : [])
                ]}
              />
            </div>
          </div>
          
          <p className="text-white/70 leading-relaxed max-w-3xl">{overview}</p>
        </div>

        {/* Controls Section */}
        <div className="space-y-6 bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem] self-start">
          <div className="flex items-center gap-2 mb-4 text-white/80 font-semibold">
            <Settings className="w-5 h-5" /> Source Settings
          </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-white/50 uppercase tracking-wider mb-2 block">Provider</label>
                <CustomSelect
                  value={provider?.id || ''}
                  onChange={(val: string) => setProvider(PROVIDERS[type as keyof typeof PROVIDERS].find(p => p.id === val))}
                  options={PROVIDERS[type as keyof typeof PROVIDERS].map(p => ({
                    value: p.id,
                    label: p.name
                  }))}
                />
              </div>

              {type === 'anime' && (
                <div>
                  <label className="text-xs text-white/50 uppercase tracking-wider mb-2 block">Audio</label>
                  <CustomSelect
                    value={subDub}
                    onChange={(val: string) => setSubDub(val)}
                    options={[
                      { value: 'sub', label: 'Subbed' },
                      { value: 'dub', label: 'Dubbed' }
                    ]}
                  />
                </div>
              )}
            </div>
        </div>
      </div>
    </div>
  );
}
