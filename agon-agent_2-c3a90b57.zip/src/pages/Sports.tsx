import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Trophy, PlayCircle, Timer } from 'lucide-react';

export default function Sports() {
  const [categories, setCategories] = useState<any[]>([]);
  const [activeCategory, setActiveCategory] = useState('football');
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState(Date.now());

  // Update 'now' every minute for countdowns
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 60000);
    return () => clearInterval(interval);
  }, []);

  const formatCountdown = (targetTime: number) => {
    const diff = targetTime - now;
    if (diff <= 0) return 'Started';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (days > 0) return `Starts in ${days}d ${hours}h`;
    if (hours > 0) return `Starts in ${hours}h ${mins}m`;
    return `Starts in ${mins}m`;
  };

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('https://api.sportsrc.org/?data=sports');
        const data = await res.json();
        if (data.success) setCategories(data.data);
      } catch (e) {
        console.error('Failed to fetch sports categories', e);
      }
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchMatches = async () => {
      setLoading(true);
      try {
        const res = await fetch(`https://api.sportsrc.org/?data=matches&category=${activeCategory}`);
        const data = await res.json();
        if (data.success) {
          // Sort matches by date (closest first)
          const sorted = data.data.sort((a: any, b: any) => a.date - b.date);
          setMatches(sorted);
        } else {
          setMatches([]);
        }
      } catch (e) {
        console.error('Failed to fetch matches', e);
        setMatches([]);
      } finally {
        setLoading(false);
      }
    };
    fetchMatches();
  }, [activeCategory]);

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight flex items-center gap-3">
          <Trophy className="w-8 h-8 text-yellow-400" /> Live Sports
        </h1>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide mb-8">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-5 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors flex-shrink-0 ${
              activeCategory === cat.id 
                ? 'bg-white text-black shadow-lg' 
                : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white border border-white/10'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" />
        </div>
      ) : matches.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {matches.map((match) => {
            const matchTime = match.date; // timestamp in ms
            const isLive = now >= matchTime && now < matchTime + (3 * 60 * 60 * 1000); // Rough 3h window
            const hasEnded = now >= matchTime + (3 * 60 * 60 * 1000);
            
            // Format time in GMT
            const dateObj = new Date(matchTime);
            const gmtDateStr = dateObj.toLocaleDateString('en-GB', { timeZone: 'UTC', month: 'short', day: 'numeric' });
            const gmtTimeStr = dateObj.toLocaleTimeString('en-GB', { timeZone: 'UTC', hour: '2-digit', minute: '2-digit' });

            return (
              <Link 
                key={match.id}
                to={`/watch/sport/${activeCategory}/${match.id}`}
                className="group bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] overflow-hidden hover:bg-white/10 transition-all hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] flex flex-col"
              >
                {/* Match Banner/Poster */}
                <div className="relative w-full aspect-video bg-black/40 border-b border-white/5">
                  {match.poster ? (
                    <img src={match.poster} alt={match.title} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Trophy className="w-12 h-12 text-white/10" />
                    </div>
                  )}
                  
                  {/* Live Badge */}
                  {isLive && (
                    <div className="absolute top-4 left-4 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider flex items-center gap-1.5 shadow-[0_0_15px_rgba(239,68,68,0.5)]">
                      <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> Live
                    </div>
                  )}
                  
                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
                      <PlayCircle className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </div>

                <div className="p-6 flex flex-col flex-1">
                  {/* Teams */}
                  <div className="flex items-center justify-between gap-4 mb-6 flex-1">
                    <div className="flex flex-col items-center gap-2 flex-1 text-center">
                      {match.teams?.home?.badge ? (
                        <img src={match.teams.home.badge} alt={match.teams.home.name} className="w-12 h-12 object-contain" />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold">{match.teams?.home?.name?.charAt(0) || '?'}</div>
                      )}
                      <span className="text-sm font-semibold line-clamp-2">{match.teams?.home?.name || 'TBA'}</span>
                    </div>
                    
                    <div className="text-white/30 font-black text-xl italic">VS</div>
                    
                    <div className="flex flex-col items-center gap-2 flex-1 text-center">
                      {match.teams?.away?.badge ? (
                        <img src={match.teams.away.badge} alt={match.teams.away.name} className="w-12 h-12 object-contain" />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold">{match.teams?.away?.name?.charAt(0) || '?'}</div>
                      )}
                      <span className="text-sm font-semibold line-clamp-2">{match.teams?.away?.name || 'TBA'}</span>
                    </div>
                  </div>

                  {/* Time/Date Footer */}
                  <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
                    <div className="flex items-center justify-between text-xs text-white/50 font-medium">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" />
                        {gmtDateStr}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        {gmtTimeStr} GMT
                      </div>
                    </div>
                    
                    {!isLive && !hasEnded && (
                      <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-indigo-400 bg-indigo-500/10 py-2 rounded-xl">
                        <Timer className="w-3.5 h-3.5" />
                        {formatCountdown(matchTime)}
                      </div>
                    )}
                    {hasEnded && (
                      <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-white/40 bg-white/5 py-2 rounded-xl">
                        Ended
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-20 text-white/50 bg-white/5 rounded-[2rem] border border-white/10">
          <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">No matches found</p>
          <p className="text-sm mt-2">There are currently no upcoming events for this category.</p>
        </div>
      )}
    </div>
  );
}
