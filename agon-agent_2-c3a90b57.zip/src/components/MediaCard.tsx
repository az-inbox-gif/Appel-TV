import { Link } from 'react-router-dom';
import { getImageUrl } from '../lib/tmdb';
import { Play } from 'lucide-react';

export default function MediaCard({ item, type }: { item: any, type: string }) {
  const title = type === 'anime' ? (item?.title?.english || item?.title?.romaji || 'Unknown') : (item?.title || item?.name || 'Unknown');
  const poster = type === 'anime' 
    ? item?.coverImage?.large 
    : getImageUrl(item?.poster_path, 'w500');
  const rating = type === 'anime' ? (item?.averageScore ? (item.averageScore / 10).toFixed(1) : null) : item?.vote_average?.toFixed(1);

  return (
    <Link 
      to={`/watch/${type}/${item.id}`}
      className="group relative block w-full aspect-[2/3] rounded-2xl overflow-hidden bg-white/5 border border-white/10 transition-transform duration-300 hover:scale-105 hover:z-10 hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] focus:outline-none focus:ring-2 focus:ring-white/50"
    >
      <img 
        src={poster} 
        alt={title} 
        className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-110"
        loading="lazy"
      />
      
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.8)_100%)] opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 pointer-events-none" />
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4 z-20">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center opacity-0 group-hover:opacity-100 scale-50 group-hover:scale-100 transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.3)]">
            <Play className="w-6 h-6 text-white fill-current ml-1" />
          </div>
        </div>
        
        <h3 className="text-white font-semibold text-sm line-clamp-2 drop-shadow-md translate-y-2 group-hover:translate-y-0 transition-transform duration-300 relative z-30">
          {title}
        </h3>
        
        {rating && (
          <div className="flex items-center gap-2 mt-1 text-xs text-white/70 translate-y-2 group-hover:translate-y-0 transition-transform duration-300 delay-75 relative z-30">
            <span className="px-1.5 py-0.5 rounded bg-white/20 backdrop-blur-sm border border-white/10 text-white font-medium">
              ★ {rating}
            </span>
            {type === 'tv' && <span>Series</span>}
            {type === 'movie' && <span>Movie</span>}
            {type === 'anime' && <span>Anime</span>}
          </div>
        )}
      </div>
    </Link>
  );
}
