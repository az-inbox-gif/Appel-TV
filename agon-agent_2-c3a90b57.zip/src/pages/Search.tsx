import { useState, useEffect } from 'react';
import { Search as SearchIcon } from 'lucide-react';
import { fetchTMDB } from '../lib/tmdb';
import { fetchAniList, ANILIST_QUERIES } from '../lib/anilist';
import MediaCard from '../components/MediaCard';

export default function Search() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{movies: any[], tv: any[], anime: any[]}>({ movies: [], tv: [], anime: [] });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (query.length < 3) {
        setResults({ movies: [], tv: [], anime: [] });
        return;
      }

      setLoading(true);
      try {
        const [movieRes, tvRes, animeRes] = await Promise.all([
          fetchTMDB('/search/movie', { query }),
          fetchTMDB('/search/tv', { query }),
          fetchAniList(ANILIST_QUERIES.search, { search: query, page: 1, perPage: 10 })
        ]);

        setResults({
          movies: movieRes.results.slice(0, 10),
          tv: tvRes.results.slice(0, 10),
          anime: animeRes.Page.media
        });
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setLoading(false);
      }
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 pb-12">
      <div className="relative max-w-2xl mx-auto mb-12 z-10">
        <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
          <SearchIcon className="w-6 h-6 text-white/50" />
        </div>
        <input
          type="text"
          className="w-full bg-white/5 backdrop-blur-xl border border-white/10 rounded-full py-5 pl-16 pr-6 text-lg focus:outline-none focus:ring-2 focus:ring-white/20 transition-all shadow-xl"
          placeholder="Search movies, tv shows, anime..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {loading && (
          <div className="absolute inset-y-0 right-6 flex items-center">
            <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
        )}
      </div>

      {query.length >= 3 && !loading && (
        <div className="space-y-12">
          {results.movies.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Movies</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                {results.movies.map(item => <MediaCard key={item.id} item={item} type="movie" />)}
              </div>
            </div>
          )}
          
          {results.tv.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">TV Shows</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                {results.tv.map(item => <MediaCard key={item.id} item={item} type="tv" />)}
              </div>
            </div>
          )}

          {results.anime.length > 0 && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Anime</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                {results.anime.map(item => <MediaCard key={item.id} item={item} type="anime" />)}
              </div>
            </div>
          )}

          {results.movies.length === 0 && results.tv.length === 0 && results.anime.length === 0 && (
            <div className="text-center text-white/50 py-12">No results found for "{query}"</div>
          )}
        </div>
      )}
    </div>
  );
}
