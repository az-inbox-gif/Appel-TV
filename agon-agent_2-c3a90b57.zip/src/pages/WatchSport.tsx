import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Trophy, Calendar, Clock } from 'lucide-react';

export default function WatchSport() {
  const { category, id } = useParams<{ category: string, id: string }>();
  const [matchDetails, setMatchDetails] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeStream, setActiveStream] = useState<string>('');
  const [iframeLoading, setIframeLoading] = useState(true);

  useEffect(() => {
    if (activeStream) setIframeLoading(true);
  }, [activeStream]);

  useEffect(() => {
    if (!category || !id) return;

    const fetchDetails = async () => {
      try {
        setLoading(true);
        const res = await fetch(`https://api.sportsrc.org/?data=detail&category=${category}&id=${id}`);
        const data = await res.json();
        
        let isMounted = true;
        if (!isMounted) return;

        if (data.success) {
          setMatchDetails(data.data);
          
          // Debug what the API is actually returning
          console.log('Match data:', data.data);

          // The API sometimes returns streams in different formats or nested objects
          const allStreams: any[] = [];
          
          if (data.data.sources && Array.isArray(data.data.sources)) {
            allStreams.push(...data.data.sources);
          } else if (data.data.streams && Array.isArray(data.data.streams)) {
            allStreams.push(...data.data.streams);
          } else if (data.data.embeds && Array.isArray(data.data.embeds)) {
            allStreams.push(...data.data.embeds);
          } else if (data.data.links && Array.isArray(data.data.links)) {
            allStreams.push(...data.data.links);
          }
          
          // Set active stream to the first available one
          if (allStreams.length > 0) {
            const firstStreamUrl = allStreams[0].embedUrl || allStreams[0].url || allStreams[0].iframe || allStreams[0].link || (typeof allStreams[0] === 'string' ? allStreams[0] : null);
            if (firstStreamUrl && typeof firstStreamUrl === 'string') {
              setActiveStream(firstStreamUrl);
            }
          }
        }
      } catch (e) {
        console.error('Failed to fetch match details', e);
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();
  }, [category, id]);

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;
  }

  if (!matchDetails) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
        <h1 className="text-3xl font-bold mb-4">Event Not Found</h1>
        <Link to="/sports" className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition-colors">Back to Sports</Link>
      </div>
    );
  }

  const matchDate = new Date(matchDetails.date);
  const isLive = matchDate.getTime() <= Date.now() && matchDate.getTime() > Date.now() - (3 * 60 * 60 * 1000);

  const gmtDateStr = matchDate.toLocaleDateString('en-AU', { timeZone: 'Australia/Sydney', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const gmtTimeStr = matchDate.toLocaleTimeString('en-AU', { timeZone: 'Australia/Sydney', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 pb-12">
      <Link to="/sports" className="inline-flex items-center gap-2 text-white/50 hover:text-white mb-6 transition-colors font-medium">
        <ChevronLeft className="w-4 h-4" /> Back to Sports
      </Link>

      <div className="flex flex-col xl:flex-row gap-6 mb-8">
        {/* Player Section */}
        <div className="relative w-full xl:w-3/4 aspect-video bg-black rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl group">
          {activeStream ? (
            <iframe 
              src={activeStream} 
              className="w-full h-full border-0" 
              allowFullScreen 
              title="Sports Player"
              sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-white/50 text-center px-4 bg-white/5">
              <Trophy className="w-12 h-12 mb-4 opacity-50" />
              <p className="text-lg font-medium">No streams available right now.</p>
              <p className="text-sm mt-2">Streams usually appear 15-30 minutes before the event starts.</p>
            </div>
          )}
        </div>

        {/* Server/Stream Selection Sidebar */}
        <div className="w-full xl:w-1/4 bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] p-6 flex flex-col h-[300px] xl:h-auto xl:aspect-[1/1.5] xl:max-h-[calc(75vw*9/16)]">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400" /> Available Streams
          </h3>
          
          <div className="flex-1 overflow-y-auto scrollbar-hide space-y-3 pr-2">
            {(() => {
              const allStreams: any[] = [];
              if (matchDetails.sources && Array.isArray(matchDetails.sources)) allStreams.push(...matchDetails.sources);
              else if (matchDetails.streams && Array.isArray(matchDetails.streams)) allStreams.push(...matchDetails.streams);
              else if (matchDetails.embeds && Array.isArray(matchDetails.embeds)) allStreams.push(...matchDetails.embeds);
              else if (matchDetails.links && Array.isArray(matchDetails.links)) allStreams.push(...matchDetails.links);

              if (allStreams.length > 0) {
                return allStreams.map((stream: any, index: number) => {
                  const streamUrl = stream.embedUrl || stream.url || stream.iframe || stream.link || (typeof stream === 'string' ? stream : '');
                  if (!streamUrl || typeof streamUrl !== 'string') return null;
                  
                  return (
                    <button
                      key={`stream-${index}`}
                      onClick={() => setActiveStream(streamUrl)}
                      className={`w-full text-left px-4 py-4 rounded-xl transition-all flex flex-col gap-1 ${
                        activeStream === streamUrl 
                          ? 'bg-white text-black shadow-lg' 
                          : 'bg-black/40 hover:bg-white/10 border border-white/5 text-white/70 hover:text-white'
                      }`}
                    >
                      <span className="font-bold text-sm">Server {index + 1} {stream.hd ? '(HD)' : ''}</span>
                      <span className={`text-[10px] uppercase tracking-wider ${activeStream === streamUrl ? 'text-black/60' : 'text-white/40'}`}>
                        {stream.language || stream.name || stream.source || 'Stream'}
                      </span>
                    </button>
                  );
                });
              } else {
                return (
                  <div className="text-center py-8 text-white/50 text-sm">
                    No active streams found.
                  </div>
                );
              }
            })()}
          </div>
        </div>
      </div>

      {/* Match Info */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-[2rem] max-w-3xl">
        <div className="flex items-center gap-3 mb-6">
          <span className="px-3 py-1 rounded-full bg-white/10 text-xs font-bold uppercase tracking-wider text-white/80">
            {matchDetails.category}
          </span>
          {isLive && (
            <span className="px-3 py-1 rounded-full bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" /> Live Now
            </span>
          )}
        </div>

        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-8">{matchDetails.title}</h1>

        <div className="flex items-center justify-between gap-4 max-w-lg mb-8">
          <div className="flex flex-col items-center gap-3 flex-1">
            {matchDetails.teams?.home?.badge ? (
              <img src={matchDetails.teams.home.badge} alt={matchDetails.teams.home.name} className="w-20 h-20 object-contain" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-xl font-bold">{matchDetails.teams?.home?.name?.charAt(0) || '?'}</div>
            )}
            <span className="font-semibold text-center">{matchDetails.teams?.home?.name || 'TBA'}</span>
          </div>
          
          <div className="text-white/30 font-black text-3xl italic">VS</div>
          
          <div className="flex flex-col items-center gap-3 flex-1">
            {matchDetails.teams?.away?.badge ? (
              <img src={matchDetails.teams.away.badge} alt={matchDetails.teams.away.name} className="w-20 h-20 object-contain" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-xl font-bold">{matchDetails.teams?.away?.name?.charAt(0) || '?'}</div>
            )}
            <span className="font-semibold text-center">{matchDetails.teams?.away?.name || 'TBA'}</span>
          </div>
        </div>

        <div className="flex items-center gap-6 text-sm text-white/60 font-medium">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            {gmtDateStr}
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            {gmtTimeStr} AEST
          </div>
        </div>
      </div>
    </div>
  );
}
