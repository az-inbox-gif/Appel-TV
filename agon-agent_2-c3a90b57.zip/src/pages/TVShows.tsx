import { useEffect, useState } from 'react';
import HeroCarousel from '../components/HeroCarousel';
import MediaRow from '../components/MediaRow';
import { fetchTMDB } from '../lib/tmdb';

export default function TVShows() {
  const [popular, setPopular] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [airing, setAiring] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [popRes, topRes, airRes] = await Promise.all([
          fetchTMDB('/tv/popular'),
          fetchTMDB('/tv/top_rated'),
          fetchTMDB('/tv/on_the_air')
        ]);

        setPopular(popRes.results);
        setTopRated(topRes.results);
        setAiring(airRes.results);
      } catch (error) {
        console.error('Failed to fetch tv shows:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="pb-10">
      <HeroCarousel items={popular} type="tv" />
      <MediaRow title="Popular TV Shows" items={popular} type="tv" />
      <MediaRow title="Top Rated TV Shows" items={topRated} type="tv" />
      <MediaRow title="Currently Airing" items={airing} type="tv" />
    </div>
  );
}
