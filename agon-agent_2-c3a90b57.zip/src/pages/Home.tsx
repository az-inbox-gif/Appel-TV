import { useEffect, useState } from 'react';
import HeroCarousel from '../components/HeroCarousel';
import MediaRow from '../components/MediaRow';
import { fetchTMDB } from '../lib/tmdb';
import { fetchAniList, ANILIST_QUERIES } from '../lib/anilist';

export default function Home() {
  const [trendingMovies, setTrendingMovies] = useState([]);
  const [trendingTV, setTrendingTV] = useState([]);
  const [trendingAnime, setTrendingAnime] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [moviesRes, tvRes, animeRes] = await Promise.all([
          fetchTMDB('/trending/movie/day'),
          fetchTMDB('/trending/tv/day'),
          fetchAniList(ANILIST_QUERIES.trending, { page: 1, perPage: 20 })
        ]);

        setTrendingMovies(moviesRes.results);
        setTrendingTV(tvRes.results);
        setTrendingAnime(animeRes.Page.media);
      } catch (error) {
        console.error('Failed to fetch home data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;
  }

  return (
    <div className="pb-10">
      <HeroCarousel items={trendingMovies} type="movie" />
      <MediaRow title="Trending Movies" items={trendingMovies} type="movie" />
      <MediaRow title="Trending TV Shows" items={trendingTV} type="tv" />
      <MediaRow title="Trending Anime" items={trendingAnime} type="anime" />
    </div>
  );
}
