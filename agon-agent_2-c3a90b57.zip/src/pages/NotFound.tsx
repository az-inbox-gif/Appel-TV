import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-4 text-center">
      <h1 className="text-6xl md:text-8xl font-black mb-6 tracking-tighter text-white/20">
        404
      </h1>
      <p className="text-2xl md:text-4xl font-bold mb-8">
        Page not found
      </p>
      <Link 
        to="/"
        className="px-8 py-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white font-semibold hover:bg-white/20 transition-colors"
      >
        Go back home
      </Link>
    </div>
  );
}
