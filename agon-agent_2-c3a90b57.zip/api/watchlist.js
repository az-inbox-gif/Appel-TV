import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) return res.status(401).json({ error: 'Invalid token' });

    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('watchlist')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    
    if (req.method === 'POST') {
      if (Array.isArray(req.body)) {
        // Bulk sync from AniList
        await supabase.from('watchlist').delete().eq('user_id', user.id).eq('media_type', 'anime');
        const inserts = req.body.map(b => ({ ...b, user_id: user.id, created_at: new Date().toISOString() }));
        const { data, error } = await supabase.from('watchlist').insert(inserts).select();
        if (error) throw error;
        return res.status(201).json(data);
      } else {
        const { media_id, media_type, title, poster_path, status } = req.body;
        
        const { data: existing } = await supabase.from('watchlist')
          .select('id').eq('user_id', user.id).eq('media_id', media_id).eq('media_type', media_type).single();
          
        if (existing) {
          const { data, error } = await supabase.from('watchlist')
            .update({ status })
            .eq('id', existing.id)
            .select().single();
          if (error) throw error;
          return res.status(200).json(data);
        } else {
          const { data, error } = await supabase.from('watchlist')
            .insert({ user_id: user.id, media_id, media_type, title, poster_path, status, created_at: new Date().toISOString() })
            .select().single();
          if (error) throw error;
          return res.status(201).json(data);
        }
      }
    }
    
    if (req.method === 'DELETE') {
      const { media_id, media_type } = req.body;
      const { error } = await supabase
        .from('watchlist')
        .delete()
        .eq('user_id', user.id)
        .eq('media_id', media_id)
        .eq('media_type', media_type);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
