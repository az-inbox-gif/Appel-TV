import { useEffect, useState } from 'react';
import HeroCarousel from '../components/HeroCarousel';
import MediaRow from '../components/MediaRow';
import { fetchAniList, ANILIST_QUERIES } from '../lib/anilist';

export default function Anime() {
  const [trending, setTrending] = useState([]);
  const [popular, setPopular] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [trendRes, popRes] = await Promise.all([
          fetchAniList(ANILIST_QUERIES.trending, { page: 1, perPage: 20 }),
          fetchAniList(ANILIST_QUERIES.popular, { page: 1, perPage: 20 })
        ]);

        setTrending(trendRes.Page.media);
        setPopular(popRes.Page.media);
      } catch (error) {
        console.error('Failed to fetch anime:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;

  return (
    <div className="pb-10">
      <HeroCarousel items={trending} type="anime" />
      <MediaRow title="Trending Anime" items={trending} type="anime" />
      <MediaRow title="All Time Popular" items={popular} type="anime" />
    </div>
  );
}
