import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import supabase from './lib/supabase';
import { handleGoogleRedirect } from './lib/googleAuth';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Movies from './pages/Movies';
import TVShows from './pages/TVShows';
import Anime from './pages/Anime';
import Watch from './pages/Watch';
import Settings from './pages/Settings';
import Search from './pages/Search';
import Watchlist from './pages/Watchlist';
import Sports from './pages/Sports';
import WatchSport from './pages/WatchSport';
import NotFound from './pages/NotFound';

function App() {
  const [session, setSession] = useState<any>(null);

  useEffect(() => {
    handleGoogleRedirect();
    
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#0a0a0c] text-white font-sans selection:bg-white/30">
        <Navbar session={session} />
        <main className="pb-12 pt-20 lg:pt-28">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/movies" element={<Movies />} />
            <Route path="/tv" element={<TVShows />} />
            <Route path="/anime" element={<Anime />} />
            <Route path="/sports" element={<Sports />} />
            <Route path="/watch/:type/:id" element={<Watch session={session} />} />
            <Route path="/watch/sport/:category/:id" element={<WatchSport />} />
            <Route path="/watchlist" element={<Watchlist session={session} />} />
            <Route path="/settings" element={<Settings session={session} />} />
            <Route path="/search" element={<Search />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
