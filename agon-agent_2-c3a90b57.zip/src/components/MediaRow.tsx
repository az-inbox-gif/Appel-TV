import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import MediaCard from './MediaCard';

export default function MediaRow({ title, items, type }: { title: string, items: any[], type: string }) {
  const rowRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth * 0.8 : scrollLeft + clientWidth * 0.8;
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="mb-12 relative max-w-[1600px] mx-auto px-4 md:px-8">
      <h2 className="text-xl md:text-2xl font-bold mb-4 px-2 text-white/90 tracking-tight">{title}</h2>
      
      <div className="relative group/row">
        <button 
          onClick={() => scroll('left')}
          className="absolute -left-4 md:-left-8 top-1/2 -translate-y-1/2 z-20 w-12 h-24 bg-black/60 backdrop-blur-md border border-white/10 rounded-r-2xl flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity disabled:opacity-0 hover:bg-black/80"
        >
          <ChevronLeft className="w-8 h-8 text-white" />
        </button>

        <div 
          ref={rowRef}
          className="flex gap-4 md:gap-6 overflow-x-auto scrollbar-hide snap-x snap-mandatory px-2 pb-4 pt-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {items.map((item, i) => (
            <div key={item.id || i} className="snap-start shrink-0 w-[calc(50%-0.5rem)] sm:w-[calc(33.333%-0.667rem)] md:w-[calc(25%-0.75rem)] lg:w-[calc(20%-0.8rem)] xl:w-[calc(16.666%-0.833rem)]">
              <MediaCard item={item} type={type} />
            </div>
          ))}
        </div>

        <button 
          onClick={() => scroll('right')}
          className="absolute -right-4 md:-right-8 top-1/2 -translate-y-1/2 z-20 w-12 h-24 bg-black/60 backdrop-blur-md border border-white/10 rounded-l-2xl flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity hover:bg-black/80"
        >
          <ChevronRight className="w-8 h-8 text-white" />
        </button>
      </div>
    </div>
  );
}
