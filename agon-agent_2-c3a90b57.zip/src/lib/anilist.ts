const ANILIST_API = 'https://graphql.anilist.co';

export const fetchAniList = async (query: string, variables: any = {}) => {
  const res = await fetch(ANILIST_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({ query, variables })
  });
  if (!res.ok) throw new Error(`AniList error: ${res.status}`);
  const data = await res.json();
  return data.data;
};

export const ANILIST_QUERIES = {
  trending: `
    query ($page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        media(sort: TRENDING_DESC, type: ANIME, isAdult: false) {
          id
          title { romaji english }
          coverImage { large extraLarge }
          bannerImage
          description
          averageScore
          episodes
          status
        }
      }
    }
  `,
  popular: `
    query ($page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        media(sort: POPULARITY_DESC, type: ANIME, isAdult: false) {
          id
          title { romaji english }
          coverImage { large }
          averageScore
        }
      }
    }
  `,
  details: `
    query ($id: Int) {
      Media(id: $id, type: ANIME) {
        id
        title { romaji english }
        coverImage { large extraLarge }
        bannerImage
        description
        averageScore
        episodes
        status
        genres
        nextAiringEpisode { episode timeUntilAiring }
      }
    }
  `,
  search: `
    query ($search: String, $page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        media(search: $search, type: ANIME, isAdult: false) {
          id
          title { romaji english }
          coverImage { large }
          averageScore
          format
        }
      }
    }
  `,
  userList: `
    query ($userName: String) {
      MediaListCollection(userName: $userName, type: ANIME) {
        lists {
          entries {
            status
            media {
              id
              title { romaji english }
              coverImage { large }
            }
          }
        }
      }
    }
  `,
  relations: `
    query ($id: Int) {
      Media(id: $id, type: ANIME) {
        relations {
          edges {
            relationType
            node {
              id
              title { romaji english }
              format
              type
            }
          }
        }
      }
    }
  `
};
