import { Link, useLocation } from 'react-router-dom';
import { Home, Film, Tv, PlaySquare, Search, Settings, User, BookmarkCheck, Menu, X, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

export default function Navbar({ session }: { session: any }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/movies', icon: Film, label: 'Movies' },
    { path: '/tv', icon: Tv, label: 'TV Shows' },
    { path: '/anime', icon: PlaySquare, label: 'Anime' },
    { path: '/sports', icon: Trophy, label: 'Live Sports' },
    { path: '/watchlist', icon: BookmarkCheck, label: 'Watchlist' },
  ];

  const rightItems = [
    { path: '/search', icon: Search, label: 'Search' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <>
      {/* Desktop Top Navbar */}
      <div className="hidden lg:flex fixed top-0 left-0 right-0 h-20 bg-black/40 backdrop-blur-3xl border-b border-white/5 z-50 px-8 items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden flex items-center justify-center bg-black shadow-[0_0_20px_rgba(255,255,255,0.2)]">
            <img src="https://i.imgur.com/TCnZZvh.png" alt="Logo" className="w-full h-full object-cover" />
          </div>
          <span className="font-semibold text-xl tracking-tight">AppelTV</span>
        </Link>

        <nav className="flex items-center gap-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative px-5 py-2.5 rounded-full transition-all duration-300 ${
                  isActive ? 'text-white' : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNavDesktop"
                    className="absolute inset-0 rounded-full bg-white/10 border border-white/10 shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)]"
                    initial={false}
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
                <span className="relative z-10 font-medium text-sm">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          {rightItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative w-10 h-10 flex items-center justify-center rounded-full transition-all duration-300 ${
                  isActive ? 'bg-white/10 text-white shadow-[inset_0_1px_1px_rgba(255,255,255,0.2)]' : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
                title={item.label}
              >
                <Icon className="w-5 h-5" />
              </Link>
            );
          })}
          <div className="w-px h-6 bg-white/10 mx-1"></div>
          <Link to="/settings" className="w-10 h-10 rounded-full overflow-hidden border border-white/10 hover:border-white/30 transition-colors">
            {session?.user?.user_metadata?.avatar_url ? (
              <img src={session.user.user_metadata.avatar_url} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-white/10 flex items-center justify-center">
                <User className="w-5 h-5 text-white/70" />
              </div>
            )}
          </Link>
        </div>
      </div>

      {/* Mobile Top Bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-black/60 backdrop-blur-xl border-b border-white/5 z-50 flex items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2" onClick={() => setMobileMenuOpen(false)}>
          <div className="w-8 h-8 rounded-xl overflow-hidden flex items-center justify-center bg-black">
            <img src="https://i.imgur.com/TCnZZvh.png" alt="Logo" className="w-full h-full object-cover" />
          </div>
          <span className="font-semibold text-lg tracking-tight">AppelTV</span>
        </Link>

        <div className="flex items-center gap-3">
          <Link to="/settings" className="w-8 h-8 rounded-full overflow-hidden border border-white/10" onClick={() => setMobileMenuOpen(false)}>
            {session?.user?.user_metadata?.avatar_url ? (
              <img src={session.user.user_metadata.avatar_url} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-white/10 flex items-center justify-center">
                <User className="w-4 h-4 text-white/70" />
              </div>
            )}
          </Link>
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="lg:hidden fixed top-16 left-0 right-0 bg-[#0a0a0c]/95 backdrop-blur-3xl border-b border-white/10 z-40 p-4 flex flex-col gap-2 shadow-2xl"
          >
            {[...navItems, ...rightItems].map((item) => {
              const isActive = location.pathname === item.path;
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-4 p-4 rounded-2xl transition-colors ${
                    isActive ? 'bg-white/10 text-white' : 'text-white/60 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-semibold">{item.label}</span>
                </Link>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
