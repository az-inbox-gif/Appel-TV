import { useEffect, useState } from 'react';
import supabase from '../lib/supabase';
import MediaCard from '../components/MediaCard';
import { BookmarkCheck } from 'lucide-react';

export default function Watchlist({ session }: { session: any }) {
  const [watchlist, setWatchlist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    if (session?.user) {
      loadWatchlist();
    } else {
      setLoading(false);
    }
  }, [session]);

  const loadWatchlist = async () => {
    try {
      const { data: authData } = await supabase.auth.getSession();
      const token = authData.session?.access_token;
      if (!token) return;

      const res = await fetch('/api/watchlist', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (res.ok) {
        setWatchlist(await res.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 text-center">
        <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center mb-8 shadow-2xl">
          <BookmarkCheck className="w-10 h-10 text-white/50" />
        </div>
        <h1 className="text-3xl font-bold mb-4 tracking-tight">Your Watchlist</h1>
        <p className="text-white/50 mb-8 max-w-md">Sign in to sync and view your watchlist across all devices.</p>
      </div>
    );
  }

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen"><div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin" /></div>;
  }

  const filteredList = filter === 'All' ? watchlist : watchlist.filter(item => item.status === filter);

  return (
    <div className="max-w-[1600px] mx-auto px-4 md:px-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Watchlist</h1>
        
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {['All', 'Watching', 'Watched', 'Planning To Watch', 'Dropped'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors ${
                filter === f 
                  ? 'bg-white text-black' 
                  : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white'
              }`}
            >
              {f === 'Planning To Watch' ? 'Plan to Watch' : f === 'Watched' ? 'Completed' : f}
            </button>
          ))}
        </div>
      </div>

      {filteredList.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {filteredList.map((item) => (
            <div key={item.id} className="relative group">
              <MediaCard 
                item={{
                  id: item.media_id,
                  title: item.title,
                  poster_path: item.media_type !== 'anime' ? item.poster_path : null,
                  coverImage: item.media_type === 'anime' ? { large: item.poster_path } : null
                }} 
                type={item.media_type} 
              />
              <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg border border-white/10 text-[10px] font-bold uppercase tracking-wider z-20">
                {item.status === 'Planning To Watch' ? 'Plan to Watch' : item.status}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 text-white/50 bg-white/5 rounded-[2rem] border border-white/10">
          <BookmarkCheck className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">No items found</p>
          <p className="text-sm mt-2">Add items to your watchlist or sync with AniList in Settings.</p>
        </div>
      )}
    </div>
  );
}
