import { useEffect, useState } from 'react';
import { signInWithGoogle } from '../lib/googleAuth';
import supabase from '../lib/supabase';
import { fetchAniList, ANILIST_QUERIES } from '../lib/anilist';
import { User, LogOut, Monitor, Database, Link as LinkIcon } from 'lucide-react';
import CustomSelect from '../components/CustomSelect';

export default function Settings({ session }: { session: any }) {
  const [profile, setProfile] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [watchlist, setWatchlist] = useState<any[]>([]);
  const [aniListUsername, setAniListUsername] = useState('');
  const [syncing, setSyncing] = useState(false);
  
  useEffect(() => {
    if (session?.user) {
      loadUserData();
    }
  }, [session]);

  const loadUserData = async () => {
    const { data: authData } = await supabase.auth.getSession();
    const token = authData.session?.access_token;
    if (!token) return;

    try {
      const [profRes, histRes, watchRes] = await Promise.all([
        fetch('/api/profile', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/history', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/watchlist', { headers: { Authorization: `Bearer ${token}` } })
      ]);
      
      if (profRes.ok) setProfile(await profRes.json());
      if (histRes.ok) setHistory(await histRes.json());
      if (watchRes.ok) setWatchlist(await watchRes.json());
    } catch (e) {
      console.error(e);
    }
  };



  const handleAniListSync = async () => {
    if (!aniListUsername) return;
    setSyncing(true);
    try {
      const res = await fetchAniList(ANILIST_QUERIES.userList, { userName: aniListUsername });
      if (!res?.MediaListCollection?.lists) throw new Error('User not found or list is empty');
      
      const entries: any[] = [];
      res.MediaListCollection.lists.forEach((list: any) => {
        list.entries.forEach((entry: any) => {
          let status = 'Planning To Watch';
          if (entry.status === 'CURRENT') status = 'Watching';
          if (entry.status === 'COMPLETED') status = 'Watched';
          if (entry.status === 'DROPPED') status = 'Dropped';
          if (entry.status === 'PAUSED') status = 'Watching';
          
          entries.push({
            media_id: entry.media.id.toString(),
            media_type: 'anime',
            title: entry.media.title.english || entry.media.title.romaji,
            poster_path: entry.media.coverImage.large,
            status
          });
        });
      });
      
      const { data: authData } = await supabase.auth.getSession();
      const token = authData.session?.access_token;
      
      const postRes = await fetch('/api/watchlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(entries)
      });
      
      if (!postRes.ok) throw new Error('Failed to save watchlist');
      
      loadUserData();
      alert(`Successfully synced ${entries.length} anime from AniList!`);
    } catch (e: any) {
      alert(e.message || 'Failed to sync AniList. Please check the username and try again.');
      console.error(e);
    } finally {
      setSyncing(false);
    }
  };



  const updateProfile = async (updates: any) => {
    const { data: authData } = await supabase.auth.getSession();
    await fetch('/api/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authData.session?.access_token}` },
      body: JSON.stringify(updates)
    });
    setProfile({ ...profile, ...updates });
  };

  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
        <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center mb-8 shadow-2xl">
          <User className="w-10 h-10 text-white/50" />
        </div>
        <h1 className="text-3xl font-bold mb-4 tracking-tight">Account & Settings</h1>
        <p className="text-white/50 mb-8 text-center max-w-md">Sign in to sync your watch history, bookmarks, and preferences across devices.</p>
        <button 
          onClick={() => signInWithGoogle('GlassStream')}
          className="flex items-center gap-3 px-8 py-4 rounded-2xl bg-white text-black font-semibold hover:scale-105 transition-transform"
        >
          <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="Google" />
          Continue with Google
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-8 pb-12">
      <h1 className="text-3xl font-bold mb-8 tracking-tight">Settings</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="md:col-span-1">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem] flex flex-col items-center text-center">
            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white/10 mb-4">
              <img src={session.user.user_metadata.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <h2 className="text-xl font-bold">{session.user.user_metadata.full_name}</h2>
            <p className="text-sm text-white/50 mb-6">{session.user.email}</p>
            
            <button 
              onClick={() => supabase.auth.signOut()}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-red-500/10 text-red-400 font-semibold hover:bg-red-500/20 transition-colors w-full justify-center"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>

        {/* Settings Options */}
        <div className="md:col-span-2 space-y-6">
          <section className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem]">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <Monitor className="w-5 h-5 text-indigo-400" /> Preferences
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm text-white/70 mb-2 block">Default Movie/TV Provider</label>
                <CustomSelect
                  value={profile?.default_movie_provider || 'vidsrc'}
                  onChange={(val) => updateProfile({ default_movie_provider: val })}
                  options={[
                    { value: 'vidsrc', label: 'VidSrc' },
                    { value: 'vidsrc-cc', label: 'VidSrc.cc' },
                    { value: 'autoembed', label: 'AutoEmbed' },
                    { value: 'embedsu', label: 'Embed.su' },
                    { value: 'vidlink', label: 'VidLink' },
                    { value: '111movies', label: '111Movies' },
                    { value: 'filmu', label: 'FilmU' }
                  ]}
                />
              </div>
              
              <div>
                <label className="text-sm text-white/70 mb-2 block">Default Anime Provider</label>
                <CustomSelect
                  value={profile?.default_anime_provider || 'vidnest'}
                  onChange={(val) => updateProfile({ default_anime_provider: val })}
                  options={[
                    { value: 'vidnest', label: 'VidNest Pahe' },
                    { value: 'yummyani', label: 'YummyAnime' },
                    { value: 'vidsrc', label: 'VidSrc (Requires TMDB ID)' },
                    { value: 'vidsrc-cc', label: 'VidSrc.cc (Requires TMDB ID)' },
                    { value: 'autoembed', label: 'AutoEmbed (Requires TMDB ID)' },
                    { value: 'embedsu', label: 'Embed.su (Requires TMDB ID)' },
                    { value: 'vidlink', label: 'VidLink (Requires TMDB ID)' },
                    { value: 'filmu', label: 'FilmU (Requires TMDB ID)' }
                  ]}
                />
              </div>
            </div>
          </section>

          <section className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem]">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <LinkIcon className="w-5 h-5 text-purple-400" /> Integrations
            </h3>
            <div className="space-y-4">
              <div className="flex flex-col gap-3 p-4 rounded-xl bg-black/40 border border-white/5">
                <div>
                  <h4 className="font-medium">AniList Sync</h4>
                  <p className="text-xs text-white/50">Import your public AniList watchlist</p>
                </div>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="AniList Username" 
                    value={aniListUsername}
                    onChange={e => setAniListUsername(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-white/30 transition-colors"
                  />
                  <button 
                    onClick={handleAniListSync}
                    disabled={syncing || !aniListUsername}
                    className="px-4 py-2 rounded-lg bg-blue-500/20 text-blue-400 text-sm font-medium hover:bg-blue-500/30 disabled:opacity-50 transition-colors"
                  >
                    {syncing ? 'Syncing...' : 'Sync'}
                  </button>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-[2rem]">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <Database className="w-5 h-5 text-green-400" /> Data
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                <div className="text-2xl font-bold mb-1">{watchlist.length}</div>
                <div className="text-xs text-white/50 uppercase tracking-wider">Watchlist</div>
              </div>
              <div className="p-4 rounded-xl bg-black/40 border border-white/5 text-center">
                <div className="text-2xl font-bold mb-1">{history.length}</div>
                <div className="text-xs text-white/50 uppercase tracking-wider">History Items</div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
